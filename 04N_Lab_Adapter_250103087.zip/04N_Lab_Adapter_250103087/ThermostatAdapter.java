
public class ThermostatAdapter implements SmartDevice {

    private final LegacyThermostat thermostat;

    public ThermostatAdapter(LegacyThermostat thermostat) {
        if (thermostat == null ) {
            throw new IllegalArgumentException("Thermostat cant be null");
        }
        this.thermostat = thermostat ;
    }

    @Override
    public void turnOn() {
        String dial = thermostat.checkDial();


        if ("IDLE".equals(dial)) {
            thermostat.rotateDial("low");
        }
    }

    @Override
    public void turnOff() {
        thermostat.rotateDial("IDLE");
    }

    @Override
    public boolean isOn() {
        String dial = thermostat.checkDial() ;


        return "low".equals(dial) || "medium".equals(dial) || "max".equals(dial);
    }

    @Override
    public int getPowerPercent() {
        String dial = thermostat.checkDial() ;

        if (dial == null) {
            return -1 ;
        }

        switch (dial) {
            case "IDLE":
                return 0;
            case "low":
                return 33 ;
            case "medium":
                return 66 ;
            case "max":
                return 100;
            default:
                return -1;
        }
    }
}
