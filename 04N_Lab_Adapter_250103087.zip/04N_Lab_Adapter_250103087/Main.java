import java.util.List ;

public class Main {

    public static void main(String[] args ) {
        LegacyBulb rawBulb = new LegacyBulb();
        LegacyThermostat rawThermostat = new LegacyThermostat() ;

        BulbAdapter bulbAdapter = new BulbAdapter(rawBulb) ;
        ThermostatAdapter thermostatAdapter =
                new ThermostatAdapter(rawThermostat);

        List<SmartDevice> devices = List.of(
                bulbAdapter,
                thermostatAdapter
        );

        ModernHub hub = new ModernHub(devices);

        hub.activateAll() ;

        System.out.println(
                "Bulb: " + bulbAdapter.isOn() + " "
                        + bulbAdapter.getPowerPercent() + "%"
        )
        ;

        System.out.println(
                "Thermostat: " + thermostatAdapter.isOn() + " "
                        + thermostatAdapter.getPowerPercent() + "%"
        );

        System.out.printf (
                "Average: %.2f%%%n",
                hub.calculateAveragePowerUsage()
        )
        ;

        rawBulb.breakFilament() ;

        System.out.println(
                "Bulb fault: " + bulbAdapter.isOn() + " "
                        + bulbAdapter.getPowerPercent() + "%"
        ) ;

        rawThermostat.rotateDial("STUCK");

        System.out.println(
                "Thermostat fault: " + thermostatAdapter.isOn() + " "
                        + thermostatAdapter.getPowerPercent()
        );

        hub.emergencyShutdown();

        System.out.println("Bulb off: " + rawBulb.readBrightness() ) ;
        System.out.println("Thermostat off: " + rawThermostat.checkDial()) ;

        System.out.printf(
                "Average: %.2f%%%n",
                hub.calculateAveragePowerUsage()
        );
    }
}